TALEP KONTROL - PORTABLE PYTHON RUNTIME

Normal kullanimda BASLAT.bat, sistemde Python yoksa resmi Python.org embeddable paketini indirir, SHA-256 dogrular ve _runtime klasorune acar.

Tamamen offline kurulum istenirse uygun resmi ZIP dosyasini bu klasore ayni adla koyun:
- x64: python-3.13.17-embeddable-amd64.zip
- ARM64: python-3.13.17-embeddable-arm64.zip
- x86: python-3.13.17-embed-win32.zip

Bootstrap resmi SHA-256 degerini kontrol etmeden ZIP'i kullanmaz.
